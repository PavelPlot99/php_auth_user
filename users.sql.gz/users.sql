-- Adminer 4.8.1 MySQL 5.7.22 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(20) NOT NULL,
  `password` varchar(200) NOT NULL,
  `name` varchar(20) NOT NULL,
  `date_birth` date NOT NULL,
  `image` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `login`, `password`, `name`, `date_birth`, `image`) VALUES
(33,	'PavelPlot99',	'$2y$10$TII33tn6cdPHChFZ3JNbzu2felw4DiQ/IdZgiJZ//SEg6KGWbVW7.',	'PavelPlot99',	'1999-12-18',	'/photos/1684834536.jpg'),
(34,	'Admin',	'$2y$10$l.LlwB2R3xdK2HzHgfBLLOGrBmpBrSkq2fKAwuT0mMc.CxtAOimf.',	'Admin',	'1888-12-18',	'/photos/1684835052.jpg');

-- 2023-05-23 09:50:43
